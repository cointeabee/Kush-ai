Kush AI Bot Instructions:

1. Open index.html in your browser to run locally.
2. Upload all files to a GitHub repo to run online via GitHub Pages.
3. Voice input: Click 'Voice' and speak your message.
4. Personality, Hinglish/Hindi understanding, and Wikipedia lookup included.
5. Fully responsive for mobile, desktop, and PWA.

Built by request.
