async function fetchWikiSummary(query) {
  const res = await fetch("https://en.wikipedia.org/api/rest_v1/page/summary/" + encodeURIComponent(query));
  if (!res.ok) return null;
  const data = await res.json();
  return data.extract ? data.extract.substring(0, 400) : null;
}
