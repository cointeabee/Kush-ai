function speak(text) {
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.voice = speechSynthesis.getVoices().find(v => v.name.includes("Male") || v.name.includes("Female")) || speechSynthesis.getVoices()[0];
  speechSynthesis.speak(utterance);
}

function toggleVoice() {
  const input = document.getElementById("user-input");
  const recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
  recognition.lang = "en-IN";
  recognition.start();
  recognition.onresult = function(event) {
    input.value = event.results[0][0].transcript;
    sendMessage();
  };
}
