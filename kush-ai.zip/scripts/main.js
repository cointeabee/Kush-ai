let personality = "Chill Bro";

function sendMessage() {
  const input = document.getElementById("user-input");
  const message = input.value.trim();
  if (!message) return;

  appendMessage("You", message);
  input.value = "";
  processMessage(message);
}

function appendMessage(sender, text) {
  const chat = document.getElementById("chat-window");
  const div = document.createElement("div");
  div.innerHTML = `<strong>${sender}:</strong> ${text}`;
  chat.appendChild(div);
  chat.scrollTop = chat.scrollHeight;
}

function processMessage(msg) {
  fetchWikiSummary(msg).then(answer => {
    const response = answer || getFallbackResponse(msg);
    appendMessage("Kush", response);
    speak(response);
  });
}

function getFallbackResponse(msg) {
  return "Hmm... I'm still learning. Can you say it differently?";
}
